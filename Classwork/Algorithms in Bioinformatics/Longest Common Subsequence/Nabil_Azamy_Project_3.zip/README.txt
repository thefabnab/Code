######################
This directory should contain the following:

-An executable jar file which will run Project 3 (LongestCommonSubsequence.jar)
-A PDF of the associated paper with the assignment (Longest Common Subsequence)
-An output file containing the output of the Jar file included (output.txt)
-A .java file containing the source code for the project (LongestCommonSubsequence.java)
-And this README (README.txt)

If you have any questions please feel free to contact me at:
516-859-0808 or email at Nabil.Azamy@gmail.com

Thanks and hope everything looks good

-Nabil Azamy
