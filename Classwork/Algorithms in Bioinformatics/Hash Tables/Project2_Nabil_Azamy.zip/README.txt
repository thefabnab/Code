To run the application simply access the jar file using a terminal window as such:

./java -jar HashAssignment.jar intput.txt

Included is the output should this not work and also you can find the source code within the src folder.
